package com.ex2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortingClass {
	public static void main(String[] args) {
		List<Items> list = new ArrayList<Items>();
		list.add(new Items(200, "TV", 45000));
		list.add(new Items(100, "Mobile", 20000));
		list.add(new Items(300, "Laptop", 30000));
		
		// First comparator for ascending order
				Comparator<Items> sortById = new Comparator<Items>() {
			public int compare(Items i1, Items i2) {
				return i1.getId() - i2.getId();
			}
		};
		// Second comparator for descending order 
		Comparator<Items> sortByIdD = new Comparator<Items>() {
			public int compare(Items i1, Items i2) {
				return i2.getId() - i1.getId();
			}
		};
		
		System.out.println("**** Sorting id by comparator in ascending order ****");
		Collections.sort(list, sortById); 
		for(Items item : list)  
			System.out.println(item);
		
		System.out.println("**** Sorting id by comparator in ascending order by SortbyIdD ****");
		Collections.sort(list, sortByIdD); 
		for(Items item : list)  
			System.out.println(item);
	 
	}
}
