package ex4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Service s= new Service();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println(" 1: ADD\n 2: DISPLAY ID\n 3: DISPLAY All IDs\n 4: SORT BY ID\n 5: SORT BY DATE OF BIRTH\n 6: SORT BY SALARY\n 7: SORT BY NAME\n 8: EXIT");
			System.out.println("Enter the input");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				Employee e=new Employee();
				System.out.println("ENTER EMPLOYEE ID");
				int id=sc.nextInt();
				e.setId(id);
				System.out.println("ENTER EMPLOYEE NAME");
				String name=sc.next();
				e.setName(name);
				System.out.println("ENTER EMPLOYEE SALARY");
				double salary=sc.nextDouble();
				e.setSalary(salary);
				System.out.println("E");
				String date=sc.next();
				Date dob;
				try {
					dob = new SimpleDateFormat("dd/MM/yyyy").parse(date);
					e.setDob(dob);
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				s.add(e);
				System.out.println("New Employee added");
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc.nextInt();
				if(s.findEmployee(id1)==null)
					System.out.println("EMPLOYEE DOES NOT EXIST/NOT FOUND");
				else
					System.out.println("Employee with id "+id1+" is "+ s.findEmployee(id1));
				break;
			case 3:
				s.getEmployee().forEach(e1 -> System.out.println(e1));
				break;
			case 4:
				s.getSortedEmployeesById().forEach(e1 -> System.out.println(e1));
				break;
			case 5:
				s.getSortedEmployeesByDob().forEach(e1 -> System.out.println(e1));
				break;
			case 6:
				s.getSortedEmployeesByName().forEach(e1 -> System.out.println(e1));
				break;
			case 7:
				s.getSortedEmployeesBySalary().forEach(e1 -> System.out.println(e1));
				break;
			case 8:
				System.out.println("THANK YOU");
				System.exit(0);
			default: 
				System.out.println("WRONG INPUT! TRY AGAIN");
				
			}
			}while(true);
	}

}