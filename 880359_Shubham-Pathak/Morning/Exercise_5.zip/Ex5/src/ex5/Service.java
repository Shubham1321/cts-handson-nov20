package ex5;

public class Service {

}
