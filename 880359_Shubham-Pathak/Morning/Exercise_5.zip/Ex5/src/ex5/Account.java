package ex5;


public class Account {

	private String name;
	private long ano;
	private double amount;
	
	public Account() {
		super();
	}
	
	public Account(long ano, String name, Double amount) {
		super();
		this.ano = ano;
		this.name = name;
		this.amount = amount;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAno() {
		return ano;
	}
	public void setAno(long ano) {
		this.ano = ano;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "Account [name=" + name + ", ano=" + ano + ", amount=" + amount + "]";
	}
	
	
	
}